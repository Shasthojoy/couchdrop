import junit.framework.TestCase;
import org.apache.sshd.SshServer;

/**
 * Created by michaellawson on 12/06/16.
 */
public class SshWorkerTestCase extends TestCase {
    public void testName() throws Exception {
        io.couchdrop.endpoints.ssh.SshWorker serverb = new io.couchdrop.endpoints.ssh.SshWorker();
        SshServer sshServer = serverb.createSshServer(5022, "", "/tmp", "http://localhost:5088");
        sshServer.start();
        while (true) {
            Thread.sleep(4000);
        }
    }
}
